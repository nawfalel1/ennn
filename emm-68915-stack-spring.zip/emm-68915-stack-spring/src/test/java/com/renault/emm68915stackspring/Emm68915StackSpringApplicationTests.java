package com.renault.emm68915stackspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Emm68915StackSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
