package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {
}
