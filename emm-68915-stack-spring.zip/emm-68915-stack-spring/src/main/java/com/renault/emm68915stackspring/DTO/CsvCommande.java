package com.renault.emm68915stackspring.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CsvCommande {
    private String reference;
    private String changer;
    private double prix;
    private String designation;
    private String segment;
    private String famille;
    private double remise;
    private Boolean dispo;
    private String type;
}
