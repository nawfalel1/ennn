package com.renault.emm68915stackspring.services;


import org.springframework.stereotype.Service;

@Service
public interface DiffereService {


}
