package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Degressif;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DegressifRepository extends JpaRepository<Degressif,Long> {
}
