package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.Model.Commande;
import com.renault.emm68915stackspring.Model.User;
import com.renault.emm68915stackspring.repository.CommandeRepository;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public interface CommandeService {

    public Page<Commande> getAll(int size , int page);

    Commande getById(Long id);

    public Commande createCommande(Commande commande);
    public Integer uploadCommande(MultipartFile file) throws IOException;

    public byte[] generateExcel() throws IOException;

}
