package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionRepository extends JpaRepository<Permission,Long> {
}
