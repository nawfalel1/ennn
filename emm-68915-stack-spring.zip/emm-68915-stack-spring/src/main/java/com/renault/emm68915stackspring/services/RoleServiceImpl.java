package com.renault.emm68915stackspring.services;


import com.renault.emm68915stackspring.DTO.RoleDTO;
import com.renault.emm68915stackspring.Model.Permission;
import com.renault.emm68915stackspring.Model.Role;
import com.renault.emm68915stackspring.Model.RoleRequest;
import com.renault.emm68915stackspring.repository.PermissionRepository;
import com.renault.emm68915stackspring.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService{

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }

    public Role createRole(RoleRequest roleRequest) {
        Role role = new Role();
        role.setName(roleRequest.getName());
        role = roleRepository.save(role);

        for (Long permissionId : roleRequest.getPermissionIds()) {
            Permission permission = permissionRepository.findById(permissionId).orElseThrow();
            role.getPermissions().add(permission);
        }
        return roleRepository.save(role);
    }

    public RoleDTO getRoleWithPermissions(Long id) {
        Role role = roleRepository.findById(id).orElseThrow();
        List<Permission> permissions = permissionRepository.findAll();

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setRole(role);
        roleDTO.setPermissions(permissions);

        return roleDTO;
    }

    public Role updateRole(Long id, RoleRequest roleRequest) {
        Role role = roleRepository.findById(id).orElseThrow();
        role.setName(roleRequest.getName());
        role.getPermissions().clear();

        for (Long permissionId : roleRequest.getPermissionIds()) {
            Permission permission = permissionRepository.findById(permissionId).orElseThrow();
            role.getPermissions().add(permission);
        }
        return roleRepository.save(role);
    }

    public void deleteRole(Long id) {
        Role role = roleRepository.findById(id).orElseThrow();
        roleRepository.delete(role);
    }
}
