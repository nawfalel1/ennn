package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Statment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatmentRepository extends JpaRepository<Statment,Long> {
}
