package com.renault.emm68915stackspring.repository;

import ch.qos.logback.core.net.server.Client;
import com.renault.emm68915stackspring.Model.Agent;
import com.renault.emm68915stackspring.Model.ClientsAgent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AgentRepository extends JpaRepository<Agent,Long> {

    @Query("select clientsagents from Agent where id=?")
    public List<ClientsAgent> getClientByAgent(Long id);
}
