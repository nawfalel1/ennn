package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.Model.Agent;
import com.renault.emm68915stackspring.Model.ClientsAgent;
import com.renault.emm68915stackspring.Model.User;
import com.renault.emm68915stackspring.repository.AgentRepository;
import com.renault.emm68915stackspring.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AgentServiceImpl implements AgentService{

    private final AgentRepository agentRepository;

    @Override
    public List<Agent> getAll() {

        List<Agent> agents = agentRepository.findAll();
        return agents;
    }

    @Override
    public Agent create(Agent agent) {
        return agentRepository.save(agent);
    }

    @Override
    public Agent findById(Long id) {
        Agent agent = agentRepository.findById(id).orElseThrow(null);
        return agent;
    }

    @Override
    public Agent updateAgent(Long id, Agent agent) {
        Agent agent1 = agentRepository.findById(id).orElseThrow(null);
        agent1.setClientsagents(agent.getClientsagents());
        agent1.setNom(agent.getNom());
        agent1.setCodeagent(agent.getCodeagent());
        agent1.setCodevendeur(agent.getCodevendeur());
        return agentRepository.save(agent1);
    }

    @Override
    public void destroy(Long id) {
        Agent agent = agentRepository.findById(id).orElseThrow(null);
        agentRepository.delete(agent);
    }

    @Override
    public List<ClientsAgent> getClientByAgent(Long id) {
        return agentRepository.getClientByAgent(id);
    }


}
