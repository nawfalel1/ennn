package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.Model.User;
import com.renault.emm68915stackspring.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
public class UserServiceImpl implements UserService{

    UserRepository userRepository;

    @Override
    public Page<User> getAll(int page , int size) {

        Pageable pageable= PageRequest.of(page,size);
        return userRepository.findAll(pageable);
    }

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User editUser(Long id , User user) {

        User user1 = userRepository.findById(id).orElseThrow();
        user1.setCode(user.getCode());
        user1.setRole(user.getRole());
        user1.setName(user.getName());
        user1.setUsername(user.getUsername());
        user1.setStatus(user.getStatus());
        return userRepository.save(user1);
    }

    @Override
    public void destroy(Long id) {

        User user = userRepository.findById(id).orElseThrow();
        userRepository.delete(user);
    }


}
