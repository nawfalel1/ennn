package com.renault.emm68915stackspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Emm68915StackSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Emm68915StackSpringApplication.class, args);
	}

}
