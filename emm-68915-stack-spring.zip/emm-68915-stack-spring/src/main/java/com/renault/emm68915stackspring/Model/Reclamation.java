package com.renault.emm68915stackspring.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Reclamation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String ncompteclient;
    private String referencereclamee;
    private String referencerecuephysique;
    private double quantitefacture;
    private double quantitereceptionne;
    private double quantitereclame;
    private double prixuntaire;
    private double valeurtotalereclame;
    private String codereclamation;
    private String numerofacture;
    private LocalDateTime datelivarison;
    private String typecommande;
    private String numeroexpedition;
    private String numerocolis;
    private String numerocmr;
    private String observations;
    private String statutreclamation;
    private String nomcreateur;
    private String coderesolution;
    private int nombrejoursresolution;
    private int nombreprintresolution;
    private String slug;
    private Boolean confirmed;
    private LocalDateTime confirmedAt;
    private LocalDateTime resoluAt;
    @OneToMany(mappedBy = "reclamation", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments;
    @OneToMany(mappedBy = "reclamation", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<EtatReclamation> etatreclamations;
}
