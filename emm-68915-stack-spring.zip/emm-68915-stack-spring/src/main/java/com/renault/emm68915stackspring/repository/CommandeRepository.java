package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Commande;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommandeRepository extends JpaRepository<Commande,Long> {
}
