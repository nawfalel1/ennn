package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.Model.Agent;
import com.renault.emm68915stackspring.Model.ClientsAgent;
import com.renault.emm68915stackspring.repository.AgentRepository;
import com.renault.emm68915stackspring.repository.ClientsAgentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class ClientsAgentServiceImpl implements ClientsAgentService {
    private final ClientsAgentRepository clientsagentRepository;
    private final AgentRepository agentRepository;

    @Autowired
    public ClientsAgentServiceImpl(ClientsAgentRepository clientsagentRepository, AgentRepository agentRepository) {
        this.clientsagentRepository = clientsagentRepository;
        this.agentRepository = agentRepository;
    }

    @Override
    public List<ClientsAgent> getAllClientsagents() {
        return clientsagentRepository.findAll();
    }

    @Override
    public ClientsAgent getClientsagentById(Long id) {
        Optional<ClientsAgent> clientsagentOptional = clientsagentRepository.findById(id);
        return clientsagentOptional.orElse(null);
    }

    @Override
    public ClientsAgent createClientsagent(ClientsAgent clientsagent) {
        // Example validation or business logic before saving
        // Validate if the agent exists
        Agent agent = agentRepository.findById(clientsagent.getAgent().getId()).orElse(null);
        if (agent == null) {
            throw new IllegalArgumentException("Agent not found with ID: " + clientsagent.getAgent().getId());
        }

        return clientsagentRepository.save(clientsagent);
    }

    @Override
    public ClientsAgent updateClientsagent(Long id, ClientsAgent clientsagent) {
        ClientsAgent existingClientsagent = clientsagentRepository.findById(id).orElse(null);
        if (existingClientsagent == null) {
            throw new IllegalArgumentException("Clientsagent not found with ID: " + id);
        }

        // Example validation or business logic before updating
        // Validate if the agent exists
        Agent agent = agentRepository.findById(clientsagent.getAgent().getId()).orElse(null);
        if (agent == null) {
            throw new IllegalArgumentException("Agent not found with ID: " + clientsagent.getAgent().getId());
        }

        clientsagent.setId(id); // Ensure the ID is set for update
        return clientsagentRepository.save(clientsagent);
    }

    @Override
    public void deleteClientsagent(Long id) {
        clientsagentRepository.deleteById(id);
    }
}
