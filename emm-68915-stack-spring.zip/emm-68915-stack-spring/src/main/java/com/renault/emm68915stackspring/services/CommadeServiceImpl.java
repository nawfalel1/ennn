package com.renault.emm68915stackspring.services;


import com.renault.emm68915stackspring.DTO.CsvCommande;
import com.renault.emm68915stackspring.Model.Commande;
import com.renault.emm68915stackspring.Model.Degressif;
import com.renault.emm68915stackspring.repository.CommandeRepository;
import com.renault.emm68915stackspring.repository.DegressifRepository;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

public class CommadeServiceImpl implements CommandeService{

    private CommandeRepository commandeRepository;
    private DegressifRepository degressifRepository;
    @Override
    public Page<Commande> getAll(int size , int page) {
        Pageable pageable = PageRequest.of(size,page);
        return commandeRepository.findAll(pageable);
    }

    @Override
    public Commande getById(Long id){
        Commande commande = commandeRepository.findById(id).orElseThrow(null);
        return commande;
    }

    @Override
    public Commande createCommande(Commande commande) {

        return commandeRepository.save(commande);
    }

    @Override
    public Integer uploadCommande(MultipartFile file) throws IOException {
        List<Degressif> products = parseCsv(file);
        degressifRepository.saveAll(products);
        return products.size();
    }

    private List<Degressif> parseCsv(MultipartFile file) throws IOException {
        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            HeaderColumnNameMappingStrategy<CsvCommande> strategy = new HeaderColumnNameMappingStrategy<>();
            strategy.setType(CsvCommande.class);

            CsvToBean<CsvCommande> csvToBean = new CsvToBeanBuilder<CsvCommande>(reader)
                    .withMappingStrategy(strategy)
                    .withIgnoreEmptyLine(true)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();

            List<CsvCommande> csvLines = csvToBean.parse();

            return csvLines.stream()
                    .map(csvLine -> {
                        Degressif product = new Degressif();
                        product.setReference(csvLine.getReference());
                        product.setChanger(csvLine.getChanger());
                        product.setPrix(csvLine.getPrix());
                        product.setDesignation(csvLine.getDesignation());
                        product.setSegment(csvLine.getSegment());
                        product.setFamille(csvLine.getFamille());
                        product.setRemise(csvLine.getRemise());
                        product.setDispo(csvLine.getDispo());
                        product.setType(csvLine.getType());
                        return product;
                    })
                    .collect(Collectors.toList());
        }
    }

    public byte[] generateExcel() throws IOException {
        List<Degressif> data = degressifRepository.findAll();

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("report");

        // Header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Référence");
        headerRow.createCell(1).setCellValue("Remplaçement");
        headerRow.createCell(2).setCellValue("Prix");
        headerRow.createCell(3).setCellValue("Désignation");
        headerRow.createCell(4).setCellValue("Segment");
        headerRow.createCell(5).setCellValue("Famille");
        headerRow.createCell(6).setCellValue("Remise");
        headerRow.createCell(7).setCellValue("Dispo");
        headerRow.createCell(8).setCellValue("Type");

        // Data rows
        int rowNum = 1;
        for (Degressif row : data) {
            Row dataRow = sheet.createRow(rowNum++);
            dataRow.createCell(0).setCellValue(row.getReference());
            dataRow.createCell(1).setCellValue(row.getChanger());
            dataRow.createCell(2).setCellValue(row.getPrix());
            dataRow.createCell(3).setCellValue(row.getDesignation());
            dataRow.createCell(4).setCellValue(row.getSegment());
            dataRow.createCell(5).setCellValue(row.getFamille());
            dataRow.createCell(6).setCellValue(row.getRemise());
            dataRow.createCell(7).setCellValue(row.getDispo());
            dataRow.createCell(8).setCellValue(row.getType());
        }

        // Write the output to a byte array
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        workbook.write(bos);
        workbook.close();

        return bos.toByteArray();
    }

}
