package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.Model.ClientsAgent;

import java.util.List;

public interface ClientsAgentService {
    List<ClientsAgent> getAllClientsagents();

    ClientsAgent getClientsagentById(Long id);

    ClientsAgent createClientsagent(ClientsAgent clientsagent);

    ClientsAgent updateClientsagent(Long id, ClientsAgent clientsagent);

    void deleteClientsagent(Long id);
}
