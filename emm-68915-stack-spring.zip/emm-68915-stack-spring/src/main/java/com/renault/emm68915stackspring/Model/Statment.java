package com.renault.emm68915stackspring.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Statment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String donneurorder;
    private String numerodonneurorder;
    private String numerodocument;
    private String numerodocumentlett;
    private LocalDate datecomptabilisation;
    private String typedecommande;
    private double montant;
    private double montantttc;
    private String champ1;
    private String champ2;
}
