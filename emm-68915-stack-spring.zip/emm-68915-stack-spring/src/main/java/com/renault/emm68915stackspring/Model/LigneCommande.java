package com.renault.emm68915stackspring.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class LigneCommande {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Integer nligne;
    private String reference;
    private Integer quantityCommande;
    private String commentaire;
    private Boolean disponibilite;
    @ManyToOne
    @JoinColumn(name = "commande_id")
    private Commande commande;
}
