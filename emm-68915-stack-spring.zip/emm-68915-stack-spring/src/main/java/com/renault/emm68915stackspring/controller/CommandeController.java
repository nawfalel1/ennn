package com.renault.emm68915stackspring.controller;


import com.renault.emm68915stackspring.services.CommandeService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@AllArgsConstructor
@RequestMapping("/commande")
public class CommandeController {

    private CommandeService commandeService;

    @GetMapping("/downloadExcel")
    public ResponseEntity<byte[]> downloadExcel() throws IOException {
        byte[] excelBytes = commandeService.generateExcel();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Report.xlsx");

        return ResponseEntity.ok().headers(headers).body(excelBytes);
    }
}
