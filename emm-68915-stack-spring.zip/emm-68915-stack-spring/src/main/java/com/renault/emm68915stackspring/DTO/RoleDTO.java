package com.renault.emm68915stackspring.DTO;


import com.renault.emm68915stackspring.Model.Permission;
import com.renault.emm68915stackspring.Model.Role;
import lombok.Data;

import java.util.List;

@Data
public class RoleDTO {

    private Role role;
    private List<Permission> permissions;

    // Getters and Setters
}
