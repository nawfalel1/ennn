package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.ClientsAgent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientsAgentRepository extends JpaRepository<ClientsAgent,Long> {
}
