package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Remise;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RemiseRepository extends JpaRepository<Remise,Long> {
}
