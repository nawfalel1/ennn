package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Reclamation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReclamationRepository extends JpaRepository<Reclamation,Long> {
}
