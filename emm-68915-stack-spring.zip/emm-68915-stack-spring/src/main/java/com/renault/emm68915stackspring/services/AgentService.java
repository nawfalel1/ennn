package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.Model.Agent;
import com.renault.emm68915stackspring.Model.ClientsAgent;

import java.util.List;

public interface AgentService {

    public List<Agent> getAll();

    public Agent create(Agent agent);

    public Agent findById(Long id);

    public Agent updateAgent(Long id, Agent agent);

    public void destroy(Long id);

    public List<ClientsAgent> getClientByAgent(Long id);
}
