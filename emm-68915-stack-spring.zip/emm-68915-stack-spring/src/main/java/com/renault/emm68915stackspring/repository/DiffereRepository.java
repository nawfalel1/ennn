package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Differe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiffereRepository extends JpaRepository<Differe,Long> {
}
