package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.LigneCommande;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LigneCommandeRepository extends JpaRepository<LigneCommande,Long> {

}
