package com.renault.emm68915stackspring.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Differe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;

    private String ncommande;
    private String typecommande;
    private String nagent;

    @Temporal(TemporalType.DATE)
    private Date datecommande;

    private String reference;
    private String description;
    private int quantity;
    private int quantityout;
    private int quantityinv;
    private double montant;
    private String commentaire;
}
