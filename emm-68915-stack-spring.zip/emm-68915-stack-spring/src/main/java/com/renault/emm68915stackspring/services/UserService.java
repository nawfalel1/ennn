package com.renault.emm68915stackspring.services;



import com.renault.emm68915stackspring.Model.User;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface UserService {


    public Page<User> getAll(int page , int size);

    public User createUser(User user);

    public User editUser(Long id , User user);

    public void destroy(Long id);
}
