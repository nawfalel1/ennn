package com.renault.emm68915stackspring.repository;

import com.renault.emm68915stackspring.Model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentRepository extends JpaRepository<Comment,Long> {
}
