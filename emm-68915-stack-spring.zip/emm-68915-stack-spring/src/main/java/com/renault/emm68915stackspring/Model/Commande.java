package com.renault.emm68915stackspring.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Commande {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String ncommandeclient;
    private String numeroCommande;
    private LocalDateTime dateCommande;
    private LocalDateTime dateLivraison;
    private String ncompteClient;
    private String typeCommande;
    private Boolean valideClient;
    private Boolean valideRcl;
    private Boolean valideMetier;
    private Double montant;
    private String nomCreateur;
    private String nomValideurRcl;
    private String nomValideurClient;
    private LocalDateTime validateAt;
    private LocalDateTime rclValideAt;
    private String compteLivraison;
    private String reserveChamp;

    @OneToMany(mappedBy = "commande")
    private List<LigneCommande> ligneCommandes;
}
