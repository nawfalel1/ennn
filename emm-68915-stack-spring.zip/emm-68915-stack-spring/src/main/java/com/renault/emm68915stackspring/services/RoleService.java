package com.renault.emm68915stackspring.services;

import com.renault.emm68915stackspring.DTO.RoleDTO;
import com.renault.emm68915stackspring.Model.Role;
import com.renault.emm68915stackspring.Model.RoleRequest;

import java.util.List;

public interface RoleService {
    public List<Role> getAllRoles();
    public Role createRole(RoleRequest roleRequest);

    public RoleDTO getRoleWithPermissions(Long id);
    public Role updateRole(Long id, RoleRequest roleRequest);
    public void deleteRole(Long id);
}
